//
//  ViewController.swift
//  collectionViewStory
//
//  Created by Mac on 5/21/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtNumber: UITextField!
    @IBOutlet weak var btnsubmit: UIButton!
    
    @IBOutlet weak var viewBox: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnsubmit.layer.cornerRadius = 25
        viewBox.layer.cornerRadius = 25
        
        viewBox.layer.masksToBounds = true
        viewBox.layer.shadowOffset = CGSize(width: -2, height: 2)
        viewBox.layer.shadowRadius = 10
        viewBox.layer.shadowOpacity = 5
        viewBox.layer.shadowColor = UIColor.green.cgColor
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }


}

