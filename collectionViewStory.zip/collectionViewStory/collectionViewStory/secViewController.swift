//
//  secViewController.swift
//  collectionViewStory
//
//  Created by Mac on 5/21/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class secViewController: UIViewController , UICollectionViewDataSource, UICollectionViewDelegate  {
   
    
    @IBOutlet weak var colleCell: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
   }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 20
    }


    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
       
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)as! cusCollectionViewCell
        
        
        cell.cellImage.image = #imageLiteral(resourceName: "402445259-apple-wallpapers.jpg")
       cell.layer.cornerRadius = cell.cellImage.frame.height/2
        cell.layer.borderWidth = 2
        cell.layer.borderColor = UIColor.red.cgColor
        
        return cell
        
    }
    

    
}
