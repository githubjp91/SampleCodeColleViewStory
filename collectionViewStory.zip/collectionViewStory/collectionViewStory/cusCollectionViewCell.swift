//
//  cusCollectionViewCell.swift
//  collectionViewStory
//
//  Created by Mac on 5/21/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class cusCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
}
